import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { cn } from '../utils/cn.js';

const PLANS = [
  {
    name: 'Boshlang‘ich',
    price: '0',
    period: '/oy',
    desc: 'Shaxsiy loyihalarni sinab ko‘rish uchun.',
    features: ['Oyiga 50 AI so‘rov', '1 aktiv loyiha', 'Community qo‘llab-quvvatlash', 'Standart tezlik'],
    highlighted: false,
    cta: 'Bepul boshlash',
  },
  {
    name: 'Pro',
    price: '29',
    period: '/oy',
    desc: 'Professional dasturchilar va jamoalar uchun.',
    features: [
      'Cheklanmagan AI so‘rov',
      'Cheklanmagan loyihalar',
      'Monaco kod muharriri',
      'Ustuvor tezlik',
      'Sayt va bot generatori',
      '24/7 qo‘llab-quvvatlash',
    ],
    highlighted: true,
    cta: 'Pro’ga o‘tish',
  },
  {
    name: 'Enterprise',
    price: 'Individual',
    period: '',
    desc: 'Katta jamoalar va kompaniyalar uchun.',
    features: [
      'Pro’dagi barcha imkoniyatlar',
      'Maxsus AI modeli sozlash',
      'SSO va audit jurnali',
      'Shaxsiy menejer',
      'SLA kafolati',
    ],
    highlighted: false,
    cta: 'Sotuv bilan bog‘lanish',
  },
];

export default function PricingCards() {
  return (
    <section id="pricing" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="section-eyebrow">Narxlar</p>
          <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
            O‘sishingizga mos reja tanlang
          </h2>
          <p className="mt-4 text-ash-300">Har qanday vaqtda bekor qiling. Yashirin to‘lovlar yo‘q.</p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className={cn(
                'relative flex flex-col rounded-2xl p-8',
                plan.highlighted
                  ? 'glass-strong border-2 border-crimson-500 shadow-glow-lg lg:-translate-y-4'
                  : 'glass'
              )}
            >
              {plan.highlighted && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-crimson-500 px-4 py-1 font-mono text-xs font-semibold uppercase tracking-wide text-white shadow-glow">
                  Eng ommabop
                </span>
              )}

              <h3 className="font-display text-xl font-bold text-white">{plan.name}</h3>
              <p className="mt-2 text-sm text-ash-300">{plan.desc}</p>

              <div className="mt-6 flex items-baseline gap-1">
                {plan.price !== 'Individual' && <span className="text-2xl font-bold text-white">$</span>}
                <span className="font-display text-4xl font-bold text-white">{plan.price}</span>
                <span className="text-sm text-ash-500">{plan.period}</span>
              </div>

              <ul className="mt-8 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-ash-300">
                    <Check size={16} className="mt-0.5 shrink-0 text-crimson-500" />
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href="#start"
                className={cn('mt-8 w-full text-center', plan.highlighted ? 'btn-primary' : 'btn-ghost')}
              >
                {plan.cta}
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
