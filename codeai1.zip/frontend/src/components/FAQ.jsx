import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const FAQS = [
  {
    q: 'CodeAI-X qanday ishlaydi?',
    a: 'Siz oddiy tilda nima kerakligini yozasiz, AI modeli buni tahlil qilib, to‘liq ishlaydigan kod, sayt yoki bot generatsiya qiladi.',
  },
  {
    q: 'Qaysi dasturlash tillari qo‘llab-quvvatlanadi?',
    a: 'JavaScript, Python, Java, C++, Go, PHP va yana 20 dan ortiq til va freymvorklar qo‘llab-quvvatlanadi.',
  },
  {
    q: 'Yaratilgan kodni tijorat loyihalarida ishlatsam bo‘ladimi?',
    a: 'Ha. Pro va Enterprise rejalarida yaratilgan barcha kod to‘liq sizniki hisoblanadi va cheklovsiz ishlatilishi mumkin.',
  },
  {
    q: 'Istalgan vaqt bekor qilsam bo‘ladimi?',
    a: 'Albatta. Obunani istalgan vaqtda profilingiz sozlamalaridan bir marta bosish bilan bekor qilishingiz mumkin.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="relative py-28">
      <div className="mx-auto max-w-3xl px-6">
        <div className="text-center">
          <p className="section-eyebrow">Savol-javob</p>
          <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
            Ko‘p so‘raladigan savollar
          </h2>
        </div>

        <div className="mt-12 space-y-4">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q} className="glass overflow-hidden rounded-2xl">
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-display font-semibold text-white">{item.q}</span>
                  <ChevronDown
                    size={20}
                    className={`shrink-0 text-crimson-500 transition-transform duration-300 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <p className="px-6 pb-5 text-sm leading-relaxed text-ash-300">{item.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
