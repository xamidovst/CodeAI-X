import React, { useEffect, useState } from 'react';

const SCRIPT = [
  { type: 'prompt', text: 'saytimga login sahifasi yasab ber' },
  { type: 'comment', text: '// CodeAI-X generatsiya qilmoqda...' },
  { type: 'code', text: "export default function Login() {" },
  { type: 'code', text: "  const [email, setEmail] = useState('');" },
  { type: 'code', text: '  return (' },
  { type: 'code', text: '    <form className="glass p-8 rounded-2xl">' },
  { type: 'code', text: '      <input placeholder="Email" />' },
  { type: 'code', text: '      <button>Kirish</button>' },
  { type: 'code', text: '    </form>' },
  { type: 'code', text: '  );' },
  { type: 'code', text: '}' },
  { type: 'success', text: '✓ 3 fayl yaratildi · 0.8s ichida' },
];

/**
 * Terminal-style typing animation representing the product's core action:
 * turning a plain-language prompt into working code, live.
 */
export default function TypingTerminal() {
  const [lineIndex, setLineIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);

  useEffect(() => {
    if (lineIndex >= SCRIPT.length) {
      const reset = setTimeout(() => {
        setLineIndex(0);
        setCharIndex(0);
      }, 2200);
      return () => clearTimeout(reset);
    }

    const current = SCRIPT[lineIndex].text;
    if (charIndex < current.length) {
      const t = setTimeout(() => setCharIndex((c) => c + 1), 18);
      return () => clearTimeout(t);
    }
    const next = setTimeout(() => {
      setLineIndex((l) => l + 1);
      setCharIndex(0);
    }, 320);
    return () => clearTimeout(next);
  }, [lineIndex, charIndex]);

  return (
    <div className="glass-strong w-full max-w-xl rounded-2xl shadow-glass">
      <div className="flex items-center gap-2 border-b border-white/[0.06] px-4 py-3">
        <span className="h-3 w-3 rounded-full bg-crimson-500/80" />
        <span className="h-3 w-3 rounded-full bg-ash-500/40" />
        <span className="h-3 w-3 rounded-full bg-ash-500/40" />
        <span className="ml-3 font-mono text-xs text-ash-500">codeai-x — ai-generator</span>
      </div>

      <div className="h-72 overflow-hidden px-5 py-4 font-mono text-[13px] leading-relaxed sm:text-sm">
        {SCRIPT.slice(0, lineIndex).map((line, i) => (
          <TerminalLine key={i} line={line} />
        ))}
        {lineIndex < SCRIPT.length && (
          <TerminalLine
            line={{ ...SCRIPT[lineIndex], text: SCRIPT[lineIndex].text.slice(0, charIndex) }}
            caret
          />
        )}
      </div>
    </div>
  );
}

function TerminalLine({ line, caret }) {
  const colorClass =
    line.type === 'prompt'
      ? 'text-white'
      : line.type === 'comment'
      ? 'text-ash-500'
      : line.type === 'success'
      ? 'text-crimson-400'
      : 'text-ash-300';

  return (
    <div className={`whitespace-pre ${colorClass}`}>
      {line.type === 'prompt' && <span className="text-crimson-500">❯ </span>}
      {line.text}
      {caret && <span className="ml-0.5 inline-block h-4 w-[7px] translate-y-0.5 animate-blink bg-crimson-400" />}
    </div>
  );
}
