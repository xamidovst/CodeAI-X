import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function CTASection() {
  return (
    <section id="start" className="relative py-20">
      <div className="mx-auto max-w-5xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass-strong relative overflow-hidden rounded-3xl px-8 py-16 text-center shadow-glow"
        >
          <div className="absolute -top-24 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-crimson-500/25 blur-3xl" />
          <h2 className="relative font-display text-3xl font-bold text-white sm:text-4xl">
            Birinchi loyihangizni bugun yarating
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl text-ash-300">
            Kredit karta talab qilinmaydi. 60 soniyada ro‘yxatdan o‘ting va AI bilan kod yozishni boshlang.
          </p>
          <a href="#" className="btn-primary relative mt-8 inline-flex text-base">
            Bepul boshlash
            <ArrowRight size={18} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
