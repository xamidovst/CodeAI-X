import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Play } from 'lucide-react';
import AnimatedBackground from './AnimatedBackground.jsx';
import TypingTerminal from './TypingTerminal.jsx';

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-24 pt-36 sm:pt-44">
      <AnimatedBackground />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-6 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-crimson-500/30 bg-crimson-500/10 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.2em] text-crimson-400">
            <Sparkles size={14} />
            Yangi avlod AI kod platformasi
          </span>

          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl">
            Fikringizni <span className="text-gradient">ishlaydigan kodga</span> aylantiring
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ash-300">
            CodeAI-X — sayt, bot va to‘liq loyihalarni oddiy so‘zlashuv orqali yaratadigan sun'iy
            intellekt platformasi. Cursor, Bolt va v0 dan tezroq, aniqroq va chiroyliroq.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a href="#start" className="btn-primary text-base">
              Bepul boshlash
              <ArrowRight size={18} />
            </a>
            <a href="#demo" className="btn-ghost text-base">
              <Play size={16} />
              Demo ko‘rish
            </a>
          </div>

          <div className="mt-12 flex flex-wrap items-center gap-x-10 gap-y-4">
            {[
              ['120K+', 'Faol dasturchi'],
              ['4.9M', 'Yaratilgan loyiha'],
              ['99.9%', 'Uptime'],
            ].map(([value, label]) => (
              <div key={label}>
                <p className="font-display text-2xl font-bold text-white">{value}</p>
                <p className="font-mono text-xs uppercase tracking-wide text-ash-500">{label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.7, ease: 'easeOut', delay: 0.15 }}
          className="flex justify-center lg:justify-end"
        >
          <div className="relative">
            <div className="absolute -inset-6 -z-10 rounded-3xl bg-crimson-600/10 blur-2xl" />
            <TypingTerminal />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
