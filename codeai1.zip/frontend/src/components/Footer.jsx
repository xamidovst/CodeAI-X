import React from 'react';
import { Terminal, Github, Twitter, Linkedin } from 'lucide-react';

const COLUMNS = [
  {
    title: 'Mahsulot',
    links: ['AI Chat', 'Kod generatori', 'Sayt generatori', 'Bot generatori'],
  },
  {
    title: 'Kompaniya',
    links: ['Biz haqimizda', 'Blog', 'Karyera', 'Aloqa'],
  },
  {
    title: 'Resurslar',
    links: ['Hujjatlar', 'API', 'Narxlar', 'Yordam markazi'],
  },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/[0.06] pb-10 pt-16">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-4">
          <div className="col-span-2 sm:col-span-1">
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-crimson-500">
                <Terminal size={16} className="text-white" />
              </span>
              <span className="font-display text-base font-bold text-white">
                CodeAI<span className="text-crimson-500">-X</span>
              </span>
            </div>
            <p className="mt-4 text-sm text-ash-500">
              Fikrdan kodgacha — sun'iy intellekt yordamida.
            </p>
            <div className="mt-5 flex gap-3">
              {[Github, Twitter, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-ash-300 transition-colors hover:border-crimson-500/50 hover:text-crimson-400"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="font-mono text-xs uppercase tracking-widest text-ash-500">{col.title}</h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-ash-300 transition-colors hover:text-white">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 sm:flex-row">
          <p className="text-xs text-ash-500">© {new Date().getFullYear()} CodeAI-X. Barcha huquqlar himoyalangan.</p>
          <div className="flex gap-6 text-xs text-ash-500">
            <a href="#" className="hover:text-white">Maxfiylik siyosati</a>
            <a href="#" className="hover:text-white">Foydalanish shartlari</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
