import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Globe, Bot, Zap, ShieldCheck, GitBranch } from 'lucide-react';

const FEATURES = [
  {
    icon: Code2,
    title: 'AI kod generatori',
    desc: 'Har qanday tildagi to‘liq, ishlaydigan kodni bir necha soniyada yozib beradi.',
  },
  {
    icon: Globe,
    title: 'Sayt generatori',
    desc: 'Matn orqali tasvirlab bering — to‘liq responsive sayt tayyor bo‘ladi.',
  },
  {
    icon: Bot,
    title: 'Telegram bot generatori',
    desc: 'Buyruqlar, integratsiyalar va logika bilan botni avtomatik yaratadi.',
  },
  {
    icon: Zap,
    title: 'Bir zumda ishlaydi',
    desc: 'Optimallashtirilgan AI dvigateli natijani real vaqt rejimida oqim shaklida beradi.',
  },
  {
    icon: GitBranch,
    title: 'Loyihalarni boshqarish',
    desc: 'Barcha loyihalaringiz, tarix va versiyalar bitta joyda saqlanadi.',
  },
  {
    icon: ShieldCheck,
    title: 'Xavfsiz va ishonchli',
    desc: 'Kodlaringiz shifrlangan holda saqlanadi, hech qachon uchinchi tomonga berilmaydi.',
  },
];

export default function FeatureCards() {
  return (
    <section id="features" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="section-eyebrow">Imkoniyatlar</p>
          <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
            Har bir xususiyat tezlik uchun yaratilgan
          </h2>
          <p className="mt-4 text-ash-300">
            Loyihangizni g‘oyadan production darajasigacha olib boradigan asboblar to‘plami.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="group glass relative rounded-2xl p-7 transition-all duration-300 hover:border-crimson-500/40 hover:shadow-glow"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-crimson-500/10 text-crimson-400 transition-colors group-hover:bg-crimson-500 group-hover:text-white">
                <f.icon size={22} strokeWidth={2} />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ash-300">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
