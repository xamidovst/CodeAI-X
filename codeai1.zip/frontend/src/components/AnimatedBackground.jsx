import React from 'react';

/**
 * Ambient animated background: grid overlay + drifting crimson glow orbs.
 * Pure CSS/Tailwind animation — no JS cost, respects prefers-reduced-motion.
 */
export default function AnimatedBackground() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 grid-overlay opacity-60" />

      <div className="absolute -top-40 -left-32 h-[420px] w-[420px] rounded-full bg-crimson-600/30 animate-pulse-glow" />
      <div className="absolute top-1/3 -right-40 h-[500px] w-[500px] rounded-full bg-crimson-500/20 animate-pulse-glow [animation-delay:1.5s]" />
      <div className="absolute bottom-0 left-1/4 h-[360px] w-[360px] rounded-full bg-crimson-700/25 animate-pulse-glow [animation-delay:3s]" />

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-base-900/40 to-base-900" />
    </div>
  );
}
