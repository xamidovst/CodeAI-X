/**
 * Merges class name strings, filtering out falsy values.
 * Lightweight alternative to `clsx` for this project.
 * @param  {...(string|boolean|undefined|null)} classes
 * @returns {string}
 */
export function cn(...classes) {
  return classes.filter(Boolean).join(' ');
}
