import React from 'react';
import Navbar from '../components/Navbar.jsx';
import Hero from '../components/Hero.jsx';
import FeatureCards from '../components/FeatureCards.jsx';
import PricingCards from '../components/PricingCards.jsx';
import FAQ from '../components/FAQ.jsx';
import CTASection from '../components/CTASection.jsx';
import Footer from '../components/Footer.jsx';

export default function Landing() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-base-900">
      <Navbar />
      <main>
        <Hero />
        <FeatureCards />
        <PricingCards />
        <FAQ />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
