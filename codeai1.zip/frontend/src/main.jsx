import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import App from './App.jsx';
import './styles/index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#121218',
            color: '#f5f5f7',
            border: '1px solid rgba(255,255,255,0.08)',
          },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>
);
