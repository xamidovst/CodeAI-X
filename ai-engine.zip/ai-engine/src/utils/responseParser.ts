/**
 * CodeAI-X AI Engine - Response Parser
 * Path: ai-engine/src/utils/responseParser.ts
 *
 * All generation prompts instruct the model to prefix every file with a
 * line of the form:
 *   FILE: <folder/path/filename.ext>
 * followed by a fenced code block. This parser splits raw model output
 * into a plain-text explanation plus a structured list of files, so the
 * Orchestrator never has to hand the backend an unstructured blob.
 */

import { EngineFileOutput, SupportedLanguage } from "../types";

const FILE_BLOCK_PATTERN =
  /FILE:\s*(.+?)\s*\n```(\w*)\n([\s\S]*?)```/g;

const EXTENSION_LANGUAGE_MAP: Record<string, SupportedLanguage> = {
  ts: "typescript",
  tsx: "react",
  js: "javascript",
  jsx: "react",
  py: "python",
  java: "java",
  c: "c",
  cpp: "cpp",
  cs: "csharp",
  php: "php",
  go: "go",
  rs: "rust",
  swift: "swift",
  kt: "kotlin",
  dart: "dart",
  sql: "sql",
  html: "html",
  css: "css",
  yml: "github-actions",
  yaml: "github-actions",
  sh: "bash",
  ps1: "powershell",
  lua: "lua",
  dockerfile: "docker",
  md: "unknown",
  json: "unknown",
};

function inferLanguage(filePath: string, fenceLang: string): SupportedLanguage {
  const lowerPath = filePath.toLowerCase();
  if (lowerPath.endsWith("dockerfile")) return "docker";

  const ext = filePath.includes(".") ? filePath.split(".").pop()!.toLowerCase() : "";
  if (EXTENSION_LANGUAGE_MAP[ext]) return EXTENSION_LANGUAGE_MAP[ext];
  if (EXTENSION_LANGUAGE_MAP[fenceLang.toLowerCase()]) {
    return EXTENSION_LANGUAGE_MAP[fenceLang.toLowerCase()];
  }
  return "unknown";
}

export interface ParsedLLMResponse {
  explanation: string;
  files: EngineFileOutput[];
}

export function parseLLMResponse(rawText: string): ParsedLLMResponse {
  const files: EngineFileOutput[] = [];
  let match: RegExpExecArray | null;

  FILE_BLOCK_PATTERN.lastIndex = 0;
  while ((match = FILE_BLOCK_PATTERN.exec(rawText)) !== null) {
    const [, path, fenceLang, content] = match;
    files.push({
      path: path.trim(),
      language: inferLanguage(path.trim(), fenceLang ?? ""),
      content: content.replace(/\n$/, ""),
    });
  }

  const explanation = rawText.replace(FILE_BLOCK_PATTERN, "").trim();

  return { explanation, files };
}

/**
 * Extracts lightweight follow-up suggestions from a trailing
 * "Next steps:" / "Suggestions:" section if the model included one.
 * Returns an empty array if none is found (this is optional metadata,
 * never required for the response to be valid).
 */
export function extractFollowUpSuggestions(explanation: string): string[] {
  const sectionMatch = explanation.match(
    /(?:next steps|suggestions|you (?:might|could) also)[:\s]*\n([\s\S]*)/i
  );
  if (!sectionMatch) return [];

  return sectionMatch[1]
    .split("\n")
    .map((line) => line.replace(/^[-*\d.)\s]+/, "").trim())
    .filter((line) => line.length > 0)
    .slice(0, 5);
}
