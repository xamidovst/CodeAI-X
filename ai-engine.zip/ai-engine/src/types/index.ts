/**
 * CodeAI-X AI Engine - Shared Types
 * Path: ai-engine/src/types/index.ts
 */

// ---------------------------------------------------------------------------
// Supported languages / frameworks
// ---------------------------------------------------------------------------

export type SupportedLanguage =
  | "html" | "css" | "javascript" | "typescript"
  | "react" | "nextjs" | "vue" | "angular"
  | "nodejs" | "express"
  | "python" | "flask" | "fastapi" | "django"
  | "java" | "spring"
  | "c" | "cpp" | "csharp"
  | "php" | "laravel"
  | "go" | "rust" | "swift" | "kotlin"
  | "dart" | "flutter"
  | "sql" | "mongodb" | "postgresql" | "redis"
  | "docker" | "git" | "github-actions"
  | "linux" | "bash" | "powershell"
  | "lua" | "roblox-lua" | "unity" | "unreal"
  | "arduino" | "raspberry-pi"
  | "unknown";

// ---------------------------------------------------------------------------
// Task classification (used by the Router to pick prompt + model)
// ---------------------------------------------------------------------------

export type TaskType =
  | "write_code"
  | "fix_bug"
  | "explain_code"
  | "optimize_code"
  | "code_review"
  | "refactor"
  | "generate_website"
  | "generate_react_app"
  | "generate_node_app"
  | "generate_python_app"
  | "generate_java_app"
  | "generate_flutter_app"
  | "generate_telegram_bot"
  | "generate_discord_bot"
  | "generate_rest_api"
  | "generate_database"
  | "generate_readme"
  | "generate_documentation"
  | "generate_tests"
  | "generate_dockerfile"
  | "generate_github_actions"
  | "generate_sql"
  | "generate_fullstack_project"
  | "generate_architecture"
  | "generate_prompt"
  | "generate_portfolio"
  | "generate_cv"
  | "generate_deployment_guide"
  | "general_chat";

export type ModelProvider = "anthropic" | "openai";

export interface ModelDefinition {
  provider: ModelProvider;
  model: string;
  contextWindow: number;
  maxOutputTokens: number;
  costTier: "low" | "medium" | "high";
  strengths: TaskType[];
}

// ---------------------------------------------------------------------------
// Conversation / project memory
// ---------------------------------------------------------------------------

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  taskType?: TaskType;
  createdAt: string;
  metadata?: Record<string, unknown>;
}

export interface GeneratedFile {
  path: string;
  language: SupportedLanguage;
  content: string;
  createdAt: string;
  messageId: string;
}

export interface ProjectFileNode {
  path: string;
  type: "file" | "directory";
  children?: ProjectFileNode[];
  language?: SupportedLanguage;
  sizeBytes?: number;
}

export interface ProjectContext {
  projectId: string;
  primaryLanguage: SupportedLanguage;
  frameworks: string[];
  fileTree: ProjectFileNode[];
  dependencies: Record<string, string>;
  lastAnalyzedAt: string | null;
}

export interface UserPreferences {
  preferredLanguage: SupportedLanguage | null;
  responseVerbosity: "concise" | "normal" | "detailed";
  codeStyle: "standard" | "airbnb" | "google" | "custom";
  includeComments: boolean;
  includeTests: boolean;
}

export interface SessionMemorySnapshot {
  sessionId: string;
  conversation: ChatMessage[];
  generatedFiles: GeneratedFile[];
  project: ProjectContext | null;
  preferences: UserPreferences;
}

// ---------------------------------------------------------------------------
// Engine request / response contracts
// ---------------------------------------------------------------------------

export interface EngineRequest {
  sessionId: string;
  userInput: string;
  taskTypeHint?: TaskType;
  languageHint?: SupportedLanguage;
  attachedFiles?: { path: string; content: string }[];
  stream?: boolean;
}

export interface EngineFileOutput {
  path: string;
  language: SupportedLanguage;
  content: string;
}

export interface EngineResponse {
  sessionId: string;
  taskType: TaskType;
  explanation: string;
  files: EngineFileOutput[];
  followUpSuggestions: string[];
  modelUsed: ModelDefinition;
  tokensUsed: { input: number; output: number };
}

export interface StreamChunk {
  type: "explanation" | "file_start" | "file_chunk" | "file_end" | "done" | "error";
  sessionId: string;
  filePath?: string;
  language?: SupportedLanguage;
  delta?: string;
  error?: string;
}

// ---------------------------------------------------------------------------
// Tool contracts
// ---------------------------------------------------------------------------

export interface ToolResult<T = unknown> {
  toolName: string;
  success: boolean;
  data?: T;
  error?: string;
}

export interface ToolDefinition<TInput = unknown, TOutput = unknown> {
  name: string;
  description: string;
  run: (input: TInput) => Promise<ToolResult<TOutput>>;
}
