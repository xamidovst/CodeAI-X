/**
 * CodeAI-X AI Engine - FileReader Tool
 * Path: ai-engine/src/tools/fileReader.ts
 *
 * Reads file contents that were attached to a request (e.g. uploaded by
 * the user through the backend). This tool never touches the actual disk
 * of the host machine - it only operates on in-memory file payloads
 * handed to it by the Orchestrator, keeping the AI Engine sandboxed and
 * side-effect free.
 */

import { ToolDefinition, ToolResult } from "../types";

export interface FileReaderInput {
  files: { path: string; content: string }[];
  targetPath?: string;
}

export interface FileReaderOutput {
  path: string;
  content: string;
  lineCount: number;
  sizeBytes: number;
}

function readOne(file: { path: string; content: string }): FileReaderOutput {
  return {
    path: file.path,
    content: file.content,
    lineCount: file.content.split("\n").length,
    sizeBytes: Buffer.byteLength(file.content, "utf8"),
  };
}

export const fileReaderTool: ToolDefinition<FileReaderInput, FileReaderOutput[]> = {
  name: "file_reader",
  description:
    "Reads one or more in-memory file payloads and returns their content plus basic metadata (line count, size).",
  async run(input: FileReaderInput): Promise<ToolResult<FileReaderOutput[]>> {
    try {
      if (!input.files || input.files.length === 0) {
        return { toolName: "file_reader", success: false, error: "No files provided." };
      }

      const target = input.targetPath
        ? input.files.filter((f) => f.path === input.targetPath)
        : input.files;

      if (input.targetPath && target.length === 0) {
        return {
          toolName: "file_reader",
          success: false,
          error: `File not found: ${input.targetPath}`,
        };
      }

      return { toolName: "file_reader", success: true, data: target.map(readOne) };
    } catch (err) {
      return {
        toolName: "file_reader",
        success: false,
        error: err instanceof Error ? err.message : "Unknown error reading files.",
      };
    }
  },
};
