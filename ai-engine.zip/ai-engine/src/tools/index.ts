/**
 * CodeAI-X AI Engine - Tool Registry
 * Path: ai-engine/src/tools/index.ts
 */

import { ToolDefinition } from "../types";
import { fileReaderTool } from "./fileReader";
import { folderAnalyzerTool, projectAnalyzerTool } from "./projectAnalyzer";
import { dependencyAnalyzerTool } from "./dependencyAnalyzer";
import { codeAnalyzerTool } from "./codeAnalyzer";
import { codeFormatterTool } from "./codeFormatter";
import { errorAnalyzerTool } from "./errorAnalyzer";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const TOOL_REGISTRY: Record<string, ToolDefinition<any, any>> = {
  [fileReaderTool.name]: fileReaderTool,
  [folderAnalyzerTool.name]: folderAnalyzerTool,
  [projectAnalyzerTool.name]: projectAnalyzerTool,
  [dependencyAnalyzerTool.name]: dependencyAnalyzerTool,
  [codeAnalyzerTool.name]: codeAnalyzerTool,
  [codeFormatterTool.name]: codeFormatterTool,
  [errorAnalyzerTool.name]: errorAnalyzerTool,
};

export {
  fileReaderTool,
  folderAnalyzerTool,
  projectAnalyzerTool,
  dependencyAnalyzerTool,
  codeAnalyzerTool,
  codeFormatterTool,
  errorAnalyzerTool,
};
