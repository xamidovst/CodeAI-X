/**
 * CodeAI-X AI Engine - FolderAnalyzer & ProjectAnalyzer Tools
 * Path: ai-engine/src/tools/projectAnalyzer.ts
 *
 * FolderAnalyzer: builds a normalized file-tree from a flat list of
 * uploaded file paths (as provided by the backend - this engine never
 * walks a real filesystem itself).
 *
 * ProjectAnalyzer: derives high-level project facts (primary language,
 * detected frameworks) from that file tree plus file contents, producing
 * a ProjectContext that feeds Memory and the prompt builders.
 */

import { ProjectFileNode, SupportedLanguage, ToolDefinition, ToolResult } from "../types";

// ---------------------------------------------------------------------------
// FolderAnalyzer
// ---------------------------------------------------------------------------

export interface FolderAnalyzerInput {
  filePaths: string[];
}

/**
 * Inserts a path (given as its already-split segments) into the tree,
 * creating intermediate directory nodes as needed.
 *
 * @param root        The current level of the tree being inserted into.
 * @param segments    Remaining path segments to insert, e.g. ["src", "index.ts"].
 * @param pathSoFar   The absolute path of `root`'s parent, used to build each
 *                    node's full path (e.g. "src" -> "src/index.ts").
 */
function insertPath(root: ProjectFileNode[], segments: string[], pathSoFar: string): void {
  const [head, ...rest] = segments;
  if (!head) return;

  const currentPath = pathSoFar ? `${pathSoFar}/${head}` : head;
  const isLeaf = rest.length === 0;

  let node = root.find((n) => n.path === currentPath);
  if (!node) {
    node = {
      path: currentPath,
      type: isLeaf ? "file" : "directory",
      children: isLeaf ? undefined : [],
    };
    root.push(node);
  }

  if (!isLeaf) {
    if (!node.children) node.children = [];
    insertPath(node.children, rest, currentPath);
  }
}

export const folderAnalyzerTool: ToolDefinition<FolderAnalyzerInput, ProjectFileNode[]> = {
  name: "folder_analyzer",
  description: "Builds a hierarchical file tree from a flat list of file paths.",
  async run(input: FolderAnalyzerInput): Promise<ToolResult<ProjectFileNode[]>> {
    try {
      const tree: ProjectFileNode[] = [];
      for (const path of input.filePaths) {
        const segments = path.split("/").filter(Boolean);
        insertPath(tree, segments, "");
      }
      return { toolName: "folder_analyzer", success: true, data: tree };
    } catch (err) {
      return {
        toolName: "folder_analyzer",
        success: false,
        error: err instanceof Error ? err.message : "Failed to analyze folder structure.",
      };
    }
  },
};

// ---------------------------------------------------------------------------
// ProjectAnalyzer
// ---------------------------------------------------------------------------

export interface ProjectAnalyzerInput {
  files: { path: string; content: string }[];
}

export interface ProjectAnalyzerOutput {
  primaryLanguage: SupportedLanguage;
  frameworks: string[];
  fileCount: number;
}

const EXTENSION_LANGUAGE_MAP: Record<string, SupportedLanguage> = {
  ".ts": "typescript",
  ".tsx": "react",
  ".js": "javascript",
  ".jsx": "react",
  ".py": "python",
  ".java": "java",
  ".c": "c",
  ".cpp": "cpp",
  ".cs": "csharp",
  ".php": "php",
  ".go": "go",
  ".rs": "rust",
  ".swift": "swift",
  ".kt": "kotlin",
  ".dart": "dart",
  ".sql": "sql",
  ".html": "html",
  ".css": "css",
};

const FRAMEWORK_SIGNATURES: [RegExp, string][] = [
  [/"react":/i, "React"],
  [/"next":/i, "Next.js"],
  [/"vue":/i, "Vue"],
  [/"@angular\/core":/i, "Angular"],
  [/"express":/i, "Express"],
  [/flask/i, "Flask"],
  [/fastapi/i, "FastAPI"],
  [/django/i, "Django"],
  [/spring-boot/i, "Spring Boot"],
  [/flutter:/i, "Flutter"],
  [/laravel\/framework/i, "Laravel"],
];

export const projectAnalyzerTool: ToolDefinition<ProjectAnalyzerInput, ProjectAnalyzerOutput> = {
  name: "project_analyzer",
  description: "Detects the primary language and frameworks used in a project from its files.",
  async run(input: ProjectAnalyzerInput): Promise<ToolResult<ProjectAnalyzerOutput>> {
    try {
      const langCounts = new Map<SupportedLanguage, number>();
      const frameworks = new Set<string>();

      for (const file of input.files) {
        const ext = file.path.slice(file.path.lastIndexOf("."));
        const lang = EXTENSION_LANGUAGE_MAP[ext];
        if (lang) langCounts.set(lang, (langCounts.get(lang) ?? 0) + 1);

        for (const [pattern, name] of FRAMEWORK_SIGNATURES) {
          if (pattern.test(file.content)) frameworks.add(name);
        }
      }

      let primaryLanguage: SupportedLanguage = "unknown";
      let max = 0;
      for (const [lang, count] of langCounts) {
        if (count > max) {
          max = count;
          primaryLanguage = lang;
        }
      }

      return {
        toolName: "project_analyzer",
        success: true,
        data: {
          primaryLanguage,
          frameworks: Array.from(frameworks),
          fileCount: input.files.length,
        },
      };
    } catch (err) {
      return {
        toolName: "project_analyzer",
        success: false,
        error: err instanceof Error ? err.message : "Failed to analyze project.",
      };
    }
  },
};
