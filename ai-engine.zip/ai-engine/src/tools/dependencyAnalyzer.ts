/**
 * CodeAI-X AI Engine - DependencyAnalyzer Tool
 * Path: ai-engine/src/tools/dependencyAnalyzer.ts
 *
 * Parses common dependency manifest files (package.json, requirements.txt,
 * pom.xml, pubspec.yaml, go.mod) to extract a normalized dependency map.
 * Used to give the LLM accurate context about what libraries are already
 * available in a project before generating new code.
 */

import { ToolDefinition, ToolResult } from "../types";

export interface DependencyAnalyzerInput {
  files: { path: string; content: string }[];
}

export interface DependencyAnalyzerOutput {
  manifestFound: string | null;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
}

function parsePackageJson(content: string): {
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
} {
  const parsed = JSON.parse(content) as {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  };
  return {
    dependencies: parsed.dependencies ?? {},
    devDependencies: parsed.devDependencies ?? {},
  };
}

function parseRequirementsTxt(content: string): Record<string, string> {
  const deps: Record<string, string> = {};
  for (const rawLine of content.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const match = line.match(/^([A-Za-z0-9_.\-]+)\s*(==|>=|<=|~=|>|<)?\s*([A-Za-z0-9_.\-]*)$/);
    if (match) {
      deps[match[1]] = match[3] || "*";
    }
  }
  return deps;
}

function parseGoMod(content: string): Record<string, string> {
  const deps: Record<string, string> = {};
  const requireBlockMatch = content.match(/require\s*\(([\s\S]*?)\)/);
  const lines = requireBlockMatch
    ? requireBlockMatch[1].split("\n")
    : content.split("\n").filter((l) => l.trim().startsWith("require "));

  for (const rawLine of lines) {
    const line = rawLine.replace(/^require\s+/, "").trim();
    const match = line.match(/^([^\s]+)\s+([^\s]+)/);
    if (match) deps[match[1]] = match[2];
  }
  return deps;
}

export const dependencyAnalyzerTool: ToolDefinition<
  DependencyAnalyzerInput,
  DependencyAnalyzerOutput
> = {
  name: "dependency_analyzer",
  description:
    "Extracts declared dependencies from manifest files (package.json, requirements.txt, go.mod).",
  async run(input: DependencyAnalyzerInput): Promise<ToolResult<DependencyAnalyzerOutput>> {
    try {
      const packageJson = input.files.find((f) => f.path.endsWith("package.json"));
      if (packageJson) {
        const { dependencies, devDependencies } = parsePackageJson(packageJson.content);
        return {
          toolName: "dependency_analyzer",
          success: true,
          data: { manifestFound: packageJson.path, dependencies, devDependencies },
        };
      }

      const requirements = input.files.find((f) => f.path.endsWith("requirements.txt"));
      if (requirements) {
        return {
          toolName: "dependency_analyzer",
          success: true,
          data: {
            manifestFound: requirements.path,
            dependencies: parseRequirementsTxt(requirements.content),
            devDependencies: {},
          },
        };
      }

      const goMod = input.files.find((f) => f.path.endsWith("go.mod"));
      if (goMod) {
        return {
          toolName: "dependency_analyzer",
          success: true,
          data: {
            manifestFound: goMod.path,
            dependencies: parseGoMod(goMod.content),
            devDependencies: {},
          },
        };
      }

      return {
        toolName: "dependency_analyzer",
        success: true,
        data: { manifestFound: null, dependencies: {}, devDependencies: {} },
      };
    } catch (err) {
      return {
        toolName: "dependency_analyzer",
        success: false,
        error: err instanceof Error ? err.message : "Failed to parse dependency manifest.",
      };
    }
  },
};
