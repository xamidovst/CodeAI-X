/**
 * CodeAI-X AI Engine - ErrorAnalyzer Tool
 * Path: ai-engine/src/tools/errorAnalyzer.ts
 *
 * Parses raw error messages / stack traces pasted by the user and
 * extracts structured signals (error type, message, file:line references)
 * so the bug-fix prompt can be grounded in precise facts rather than the
 * model re-reading an unstructured wall of text.
 */

import { ToolDefinition, ToolResult } from "../types";

export interface ErrorAnalyzerInput {
  rawError: string;
}

export interface StackFrame {
  file: string;
  line: number;
  column?: number;
  functionName?: string;
}

export interface ErrorAnalyzerOutput {
  errorType: string | null;
  message: string | null;
  frames: StackFrame[];
  likelyLanguage: "javascript" | "typescript" | "python" | "java" | "unknown";
}

const JS_FRAME_PATTERN = /at\s+(?:(\S+)\s+)?\(?([^\s():]+):(\d+):(\d+)\)?/g;
const PY_FRAME_PATTERN = /File "([^"]+)", line (\d+), in (\S+)/g;
const JAVA_FRAME_PATTERN = /at\s+([\w.$]+)\(([^:]+):(\d+)\)/g;

function detectLanguage(raw: string): ErrorAnalyzerOutput["likelyLanguage"] {
  if (/Traceback \(most recent call last\)/.test(raw)) return "python";
  if (/^\s*at\s+.+\(.+\.java:\d+\)/m.test(raw)) return "java";
  if (/\.ts:\d+/.test(raw)) return "typescript";
  if (/\.js:\d+/.test(raw) || /at\s+/.test(raw)) return "javascript";
  return "unknown";
}

function extractJsFrames(raw: string): StackFrame[] {
  const frames: StackFrame[] = [];
  let match: RegExpExecArray | null;
  JS_FRAME_PATTERN.lastIndex = 0;
  while ((match = JS_FRAME_PATTERN.exec(raw)) !== null) {
    frames.push({
      functionName: match[1],
      file: match[2],
      line: parseInt(match[3], 10),
      column: parseInt(match[4], 10),
    });
  }
  return frames;
}

function extractPyFrames(raw: string): StackFrame[] {
  const frames: StackFrame[] = [];
  let match: RegExpExecArray | null;
  PY_FRAME_PATTERN.lastIndex = 0;
  while ((match = PY_FRAME_PATTERN.exec(raw)) !== null) {
    frames.push({ file: match[1], line: parseInt(match[2], 10), functionName: match[3] });
  }
  return frames;
}

function extractJavaFrames(raw: string): StackFrame[] {
  const frames: StackFrame[] = [];
  let match: RegExpExecArray | null;
  JAVA_FRAME_PATTERN.lastIndex = 0;
  while ((match = JAVA_FRAME_PATTERN.exec(raw)) !== null) {
    frames.push({ functionName: match[1], file: match[2], line: parseInt(match[3], 10) });
  }
  return frames;
}

export const errorAnalyzerTool: ToolDefinition<ErrorAnalyzerInput, ErrorAnalyzerOutput> = {
  name: "error_analyzer",
  description:
    "Parses a raw error message or stack trace into a structured error type, message, and file:line stack frames.",
  async run(input: ErrorAnalyzerInput): Promise<ToolResult<ErrorAnalyzerOutput>> {
    try {
      const raw = input.rawError;
      const language = detectLanguage(raw);

      let errorType: string | null = null;
      let message: string | null = null;
      let frames: StackFrame[] = [];

      if (language === "python") {
        const headerMatch = raw.match(/(\w+(?:Error|Exception|Warning)):\s*(.*)/);
        if (headerMatch) {
          errorType = headerMatch[1];
          message = headerMatch[2].trim();
        }
        frames = extractPyFrames(raw);
      } else if (language === "java") {
        const headerMatch = raw.match(/^([\w.]+(?:Exception|Error)):?\s*(.*)$/m);
        if (headerMatch) {
          errorType = headerMatch[1];
          message = headerMatch[2].trim();
        }
        frames = extractJavaFrames(raw);
      } else {
        const headerMatch = raw.match(/^(\w+(?:Error|Exception)):\s*(.*)$/m);
        if (headerMatch) {
          errorType = headerMatch[1];
          message = headerMatch[2].trim();
        }
        frames = extractJsFrames(raw);
      }

      return {
        toolName: "error_analyzer",
        success: true,
        data: { errorType, message, frames, likelyLanguage: language },
      };
    } catch (err) {
      return {
        toolName: "error_analyzer",
        success: false,
        error: err instanceof Error ? err.message : "Failed to analyze error.",
      };
    }
  },
};
