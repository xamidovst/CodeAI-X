/**
 * CodeAI-X AI Engine - CodeAnalyzer Tool
 * Path: ai-engine/src/tools/codeAnalyzer.ts
 *
 * Lightweight, dependency-free static analysis used to give the LLM
 * concrete signals before it reviews/fixes/optimizes code. This is not a
 * replacement for a real linter/AST analysis pipeline (the backend may
 * run ESLint/Pylint separately) - it is a fast, zero-dependency first
 * pass the AI Engine can run on any language.
 */

import { ToolDefinition, ToolResult } from "../types";

export interface CodeAnalyzerInput {
  path: string;
  content: string;
}

export interface CodeIssue {
  line: number;
  severity: "info" | "warning" | "critical";
  message: string;
}

export interface CodeAnalyzerOutput {
  path: string;
  lineCount: number;
  longestLine: number;
  issues: CodeIssue[];
}

const SECRET_PATTERNS: RegExp[] = [
  /api[_-]?key\s*=\s*["'][^"']+["']/i,
  /secret\s*=\s*["'][^"']+["']/i,
  /password\s*=\s*["'][^"']+["']/i,
  /-----BEGIN (RSA|EC|DSA) PRIVATE KEY-----/,
];

const MAX_RECOMMENDED_LINE_LENGTH = 120;
const MAX_RECOMMENDED_FUNCTION_LINES = 80;

export const codeAnalyzerTool: ToolDefinition<CodeAnalyzerInput, CodeAnalyzerOutput> = {
  name: "code_analyzer",
  description:
    "Runs fast heuristic static analysis on a single file: detects hardcoded secrets, overly long lines, and oversized functions.",
  async run(input: CodeAnalyzerInput): Promise<ToolResult<CodeAnalyzerOutput>> {
    try {
      const lines = input.content.split("\n");
      const issues: CodeIssue[] = [];
      let longestLine = 0;
      let currentFunctionStart: number | null = null;
      let openBraces = 0;

      lines.forEach((line, idx) => {
        const lineNumber = idx + 1;
        longestLine = Math.max(longestLine, line.length);

        if (line.length > MAX_RECOMMENDED_LINE_LENGTH) {
          issues.push({
            line: lineNumber,
            severity: "info",
            message: `Line exceeds ${MAX_RECOMMENDED_LINE_LENGTH} characters (${line.length}).`,
          });
        }

        for (const pattern of SECRET_PATTERNS) {
          if (pattern.test(line)) {
            issues.push({
              line: lineNumber,
              severity: "critical",
              message: "Possible hardcoded secret/credential detected.",
            });
          }
        }

        if (/\bfunction\b|=>\s*{|def\s+\w+\(/.test(line) && currentFunctionStart === null) {
          currentFunctionStart = lineNumber;
          openBraces = 0;
        }
        if (currentFunctionStart !== null) {
          openBraces += (line.match(/{/g) ?? []).length;
          openBraces -= (line.match(/}/g) ?? []).length;
          if (openBraces <= 0 && lineNumber > currentFunctionStart) {
            const length = lineNumber - currentFunctionStart;
            if (length > MAX_RECOMMENDED_FUNCTION_LINES) {
              issues.push({
                line: currentFunctionStart,
                severity: "warning",
                message: `Function spans ${length} lines - consider splitting it up.`,
              });
            }
            currentFunctionStart = null;
          }
        }

        if (/console\.log\(/.test(line) || /print\(/.test(line)) {
          issues.push({
            line: lineNumber,
            severity: "info",
            message: "Debug print statement found - remove before shipping to production.",
          });
        }
      });

      return {
        toolName: "code_analyzer",
        success: true,
        data: { path: input.path, lineCount: lines.length, longestLine, issues },
      };
    } catch (err) {
      return {
        toolName: "code_analyzer",
        success: false,
        error: err instanceof Error ? err.message : "Failed to analyze code.",
      };
    }
  },
};
