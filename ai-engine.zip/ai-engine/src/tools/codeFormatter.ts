/**
 * CodeAI-X AI Engine - CodeFormatter Tool
 * Path: ai-engine/src/tools/codeFormatter.ts
 *
 * Applies deterministic whitespace/formatting normalization that is safe
 * across languages without requiring a language-specific formatter
 * dependency (Prettier/Black are expected to run on the backend/CI side
 * for full formatting; this tool provides a fast baseline pass usable
 * directly inside the engine, e.g. before returning generated code).
 */

import { ToolDefinition, ToolResult } from "../types";

export interface CodeFormatterInput {
  content: string;
  indentSize?: number;
}

export interface CodeFormatterOutput {
  content: string;
  changed: boolean;
}

export const codeFormatterTool: ToolDefinition<CodeFormatterInput, CodeFormatterOutput> = {
  name: "code_formatter",
  description:
    "Normalizes whitespace: converts tabs to spaces, trims trailing whitespace, collapses 3+ blank lines, and ensures a single trailing newline.",
  async run(input: CodeFormatterInput): Promise<ToolResult<CodeFormatterOutput>> {
    try {
      const indentSize = input.indentSize ?? 2;
      const original = input.content;

      let formatted = original.replace(/\t/g, " ".repeat(indentSize));
      formatted = formatted
        .split("\n")
        .map((line) => line.replace(/[ \t]+$/g, ""))
        .join("\n");
      formatted = formatted.replace(/\n{3,}/g, "\n\n");
      formatted = formatted.replace(/\s+$/g, "") + "\n";

      return {
        toolName: "code_formatter",
        success: true,
        data: { content: formatted, changed: formatted !== original },
      };
    } catch (err) {
      return {
        toolName: "code_formatter",
        success: false,
        error: err instanceof Error ? err.message : "Failed to format code.",
      };
    }
  },
};
