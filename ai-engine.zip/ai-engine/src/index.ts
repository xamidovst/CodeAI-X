/**
 * CodeAI-X AI Engine - Public Entry Point
 * Path: ai-engine/src/index.ts
 *
 * This is the ONLY file the backend team should import from. It exposes
 * a single `AIEngine` facade class plus the type contracts needed to call
 * it. Internal modules (core/, memory/, prompts/, tools/) are
 * implementation details and are not part of the public API surface.
 *
 * Usage from the backend:
 *
 *   import { AIEngine } from "@codeai-x/ai-engine";
 *
 *   const engine = new AIEngine();
 *
 *   const response = await engine.chat({
 *     sessionId: "user-123-session-1",
 *     userInput: "Build me a REST API for a todo list in Node.js",
 *   });
 *
 *   // response.explanation -> human-readable explanation
 *   // response.files       -> [{ path, language, content }, ...]
 */

import { Orchestrator } from "./core/orchestrator";
import { MemoryManager, MemoryStore } from "./memory/memoryManager";
import { LLMClient } from "./core/llmClient";
import {
  EngineRequest,
  EngineResponse,
  SessionMemorySnapshot,
  StreamChunk,
  UserPreferences,
} from "./types";
import * as Generators from "./generators";

export class AIEngine {
  private readonly orchestrator: Orchestrator;
  private readonly memory: MemoryManager;

  constructor(options?: { memoryStore?: MemoryStore }) {
    this.memory = new MemoryManager(options?.memoryStore);
    this.orchestrator = new Orchestrator(this.memory, new LLMClient());
  }

  /** Main conversational entry point - handles any supported task type. */
  public async chat(request: EngineRequest): Promise<EngineResponse> {
    return this.orchestrator.handleRequest(request);
  }

  /** Streaming variant of `chat`. `onChunk` fires for every incremental update. */
  public async chatStream(
    request: EngineRequest,
    onChunk: (chunk: StreamChunk) => void
  ): Promise<EngineResponse> {
    return this.orchestrator.handleRequestStreaming(request, onChunk);
  }

  /** Returns the full memory snapshot for a session (conversation, files, project, prefs). */
  public async getSessionMemory(sessionId: string): Promise<SessionMemorySnapshot> {
    return this.memory.getSnapshot(sessionId);
  }

  /** Updates stored user preferences for a session (verbosity, code style, etc.). */
  public async setPreferences(
    sessionId: string,
    preferences: Partial<UserPreferences>
  ): Promise<UserPreferences> {
    return this.memory.updatePreferences(sessionId, preferences);
  }

  /** Clears all memory for a session. */
  public async clearSession(sessionId: string): Promise<void> {
    return this.memory.clearSession(sessionId);
  }

  /** Access to task-specific generators (README, tests, Dockerfile, CI, REST API, ...). */
  public get generators() {
    return {
      readme: (input: Omit<Generators.ReadmeGeneratorInput, "sessionId"> & { sessionId: string }) =>
        Generators.generateReadme(this.orchestrator, input),
      tests: (input: Omit<Generators.TestGeneratorInput, "sessionId"> & { sessionId: string }) =>
        Generators.generateTests(this.orchestrator, input),
      dockerfile: (
        input: Omit<Generators.DockerfileGeneratorInput, "sessionId"> & { sessionId: string }
      ) => Generators.generateDockerfile(this.orchestrator, input),
      githubActions: (
        input: Omit<Generators.GithubActionsGeneratorInput, "sessionId"> & { sessionId: string }
      ) => Generators.generateGithubActions(this.orchestrator, input),
      restApi: (
        input: Omit<Generators.RestApiGeneratorInput, "sessionId"> & { sessionId: string }
      ) => Generators.generateRestApi(this.orchestrator, input),
    };
  }
}

// Re-export types the backend will need to construct requests / read responses.
export type {
  EngineRequest,
  EngineResponse,
  EngineFileOutput,
  StreamChunk,
  ChatMessage,
  GeneratedFile,
  ProjectContext,
  ProjectFileNode,
  UserPreferences,
  SessionMemorySnapshot,
  TaskType,
  SupportedLanguage,
  ModelDefinition,
} from "./types";

export type { MemoryStore } from "./memory/memoryManager";
