/**
 * CodeAI-X AI Engine - Router
 * Path: ai-engine/src/core/router.ts
 *
 * Responsible for:
 *   1. Classifying free-form user input into a TaskType.
 *   2. Detecting the target programming language / framework.
 *   3. Selecting the best ModelDefinition for the classified task.
 *
 * The classifier uses fast, deterministic keyword/pattern matching first
 * (cheap, zero-latency, no LLM call). If no rule matches confidently, the
 * caller (Orchestrator) falls back to an LLM-based classification prompt.
 */

import { EngineRequest, ModelDefinition, SupportedLanguage, TaskType } from "../types";
import { DEFAULT_MODEL, getModelsForTask } from "../config/models";

interface ClassificationRule {
  taskType: TaskType;
  patterns: RegExp[];
}

// Order matters: more specific rules are placed before generic ones.
const RULES: ClassificationRule[] = [
  { taskType: "generate_telegram_bot", patterns: [/telegram bot/i, /telegraf/i, /telegram\s*api/i] },
  { taskType: "generate_discord_bot", patterns: [/discord bot/i, /discord\.js/i, /discord\s*api/i] },
  { taskType: "generate_flutter_app", patterns: [/flutter/i, /dart\s*app/i] },
  { taskType: "generate_react_app", patterns: [/react app/i, /react component/i, /next\.?js/i] },
  { taskType: "generate_node_app", patterns: [/node\.?js (app|server|backend)/i, /express (app|server)/i] },
  { taskType: "generate_python_app", patterns: [/python (app|script)/i, /flask|fastapi|django/i] },
  { taskType: "generate_java_app", patterns: [/java (app|project)/i, /spring boot/i] },
  { taskType: "generate_rest_api", patterns: [/rest api/i, /restful/i, /\bapi endpoint/i] },
  { taskType: "generate_database", patterns: [/database schema/i, /db schema/i, /data model/i] },
  { taskType: "generate_sql", patterns: [/\bsql\b/i, /\bquery\b.*\btable\b/i] },
  { taskType: "generate_website", patterns: [/website/i, /landing page/i, /html.*css/i] },
  { taskType: "generate_readme", patterns: [/readme/i] },
  { taskType: "generate_documentation", patterns: [/documentation/i, /docs? for/i] },
  { taskType: "generate_tests", patterns: [/unit test/i, /write tests?/i, /test cases?/i] },
  { taskType: "generate_dockerfile", patterns: [/dockerfile/i, /docker(ize| container)/i] },
  { taskType: "generate_github_actions", patterns: [/github actions?/i, /ci\/cd/i, /workflow yaml/i] },
  { taskType: "generate_fullstack_project", patterns: [/full[-\s]?stack/i] },
  { taskType: "generate_architecture", patterns: [/architecture/i, /system design/i] },
  { taskType: "generate_portfolio", patterns: [/portfolio (site|website)/i] },
  { taskType: "generate_cv", patterns: [/\bcv\b/i, /resume/i] },
  { taskType: "generate_deployment_guide", patterns: [/deploy(ment)?/i, /how to host/i] },
  { taskType: "generate_prompt", patterns: [/write a prompt/i, /prompt for/i] },
  { taskType: "fix_bug", patterns: [/bug/i, /error/i, /exception/i, /not working/i, /crash(es|ing)?/i, /doesn'?t work/i] },
  { taskType: "optimize_code", patterns: [/optimi[sz]e/i, /make.*faster/i, /performance/i] },
  { taskType: "refactor", patterns: [/refactor/i, /clean up.*code/i, /restructure/i] },
  { taskType: "code_review", patterns: [/review.*code/i, /code review/i] },
  { taskType: "explain_code", patterns: [/explain/i, /what does this (code|function) do/i, /how does this work/i] },
  { taskType: "write_code", patterns: [/write.*code/i, /create a function/i, /implement/i, /build (a|an)/i] },
];

const LANGUAGE_PATTERNS: [RegExp, SupportedLanguage][] = [
  [/typescript|\.ts\b/i, "typescript"],
  [/javascript|\.js\b/i, "javascript"],
  [/react/i, "react"],
  [/next\.?js/i, "nextjs"],
  [/vue/i, "vue"],
  [/angular/i, "angular"],
  [/node\.?js/i, "nodejs"],
  [/express/i, "express"],
  [/flask/i, "flask"],
  [/fastapi/i, "fastapi"],
  [/django/i, "django"],
  [/python/i, "python"],
  [/spring/i, "spring"],
  [/java\b/i, "java"],
  [/c\+\+|cpp/i, "cpp"],
  [/c#|csharp/i, "csharp"],
  [/\bc\b/i, "c"],
  [/laravel/i, "laravel"],
  [/php/i, "php"],
  [/\bgo(lang)?\b/i, "go"],
  [/rust/i, "rust"],
  [/swift/i, "swift"],
  [/kotlin/i, "kotlin"],
  [/flutter/i, "flutter"],
  [/dart/i, "dart"],
  [/postgres/i, "postgresql"],
  [/mongo/i, "mongodb"],
  [/redis/i, "redis"],
  [/docker/i, "docker"],
  [/bash|shell script/i, "bash"],
  [/powershell/i, "powershell"],
  [/roblox/i, "roblox-lua"],
  [/\blua\b/i, "lua"],
  [/unity/i, "unity"],
  [/unreal/i, "unreal"],
  [/arduino/i, "arduino"],
  [/raspberry pi/i, "raspberry-pi"],
  [/html/i, "html"],
  [/css/i, "css"],
  [/sql/i, "sql"],
];

export class Router {
  /**
   * Classifies the user's input into a TaskType using deterministic rules.
   * Returns "general_chat" if nothing matches, signalling that the
   * Orchestrator should treat this as a normal conversational turn.
   */
  public classifyTask(request: EngineRequest): TaskType {
    if (request.taskTypeHint) return request.taskTypeHint;

    const text = request.userInput;
    for (const rule of RULES) {
      if (rule.patterns.some((p) => p.test(text))) {
        return rule.taskType;
      }
    }
    return "general_chat";
  }

  /**
   * Detects the target language/framework from the input text.
   * Falls back to the explicit hint, then to "unknown".
   */
  public detectLanguage(request: EngineRequest): SupportedLanguage {
    if (request.languageHint) return request.languageHint;

    for (const [pattern, lang] of LANGUAGE_PATTERNS) {
      if (pattern.test(request.userInput)) return lang;
    }
    return "unknown";
  }

  /**
   * Picks the best model for a given task. Currently picks the first
   * (highest-priority) match from the registry; this is the single place
   * to extend with load-based or cost-based routing later.
   */
  public selectModel(taskType: TaskType): ModelDefinition {
    const candidates = getModelsForTask(taskType);
    return candidates[0] ?? DEFAULT_MODEL;
  }
}
