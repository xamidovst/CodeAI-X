/**
 * CodeAI-X AI Engine - Orchestrator
 * Path: ai-engine/src/core/orchestrator.ts
 *
 * The single entry point the backend calls for every AI request. It:
 *   1. Classifies the task and target language via the Router.
 *   2. Loads conversation + project memory relevant to the session.
 *   3. Runs relevant tools (project analysis, dependency analysis, error
 *      analysis) to ground the prompt in concrete facts.
 *   4. Builds the task-specific system prompt.
 *   5. Calls the LLM (streaming or non-streaming).
 *   6. Parses the response into an explanation + structured files.
 *   7. Persists the turn and generated files back into memory.
 */

import { Router } from "./router";
import { LLMClient, LLMMessage, LLMStreamHandlers } from "./llmClient";
import { MemoryManager } from "../memory/memoryManager";
import { buildSystemPrompt } from "../prompts/systemPrompts";
import { projectAnalyzerTool } from "../tools/projectAnalyzer";
import { dependencyAnalyzerTool } from "../tools/dependencyAnalyzer";
import { errorAnalyzerTool } from "../tools/errorAnalyzer";
import { parseLLMResponse, extractFollowUpSuggestions } from "../utils/responseParser";
import {
  EngineRequest,
  EngineResponse,
  ProjectContext,
  StreamChunk,
  TaskType,
} from "../types";

const BUG_FIX_TASKS: TaskType[] = ["fix_bug"];

export class Orchestrator {
  private readonly router: Router;
  private readonly memory: MemoryManager;
  private readonly llm: LLMClient;

  constructor(memory?: MemoryManager, llm?: LLMClient, router?: Router) {
    this.router = router ?? new Router();
    this.memory = memory ?? new MemoryManager();
    this.llm = llm ?? new LLMClient();
  }

  /**
   * Builds the full prompt context: task classification, language
   * detection, project analysis (if files are attached), dependency
   * analysis, and recent conversation transcript.
   */
  private async buildContext(request: EngineRequest) {
    const taskType = this.router.classifyTask(request);
    const language = this.router.detectLanguage(request);
    const model = this.router.selectModel(taskType);

    const snapshot = await this.memory.getSnapshot(request.sessionId);
    let projectSummaryLines: string[] = [];

    if (request.attachedFiles && request.attachedFiles.length > 0) {
      const analysis = await projectAnalyzerTool.run({ files: request.attachedFiles });
      const deps = await dependencyAnalyzerTool.run({ files: request.attachedFiles });

      if (analysis.success && analysis.data) {
        const project: ProjectContext = {
          projectId: request.sessionId,
          primaryLanguage: analysis.data.primaryLanguage,
          frameworks: analysis.data.frameworks,
          fileTree: [],
          dependencies:
            deps.success && deps.data
              ? { ...deps.data.dependencies, ...deps.data.devDependencies }
              : {},
          lastAnalyzedAt: new Date().toISOString(),
        };
        await this.memory.updateProjectContext(request.sessionId, project);

        projectSummaryLines.push(
          `Primary language: ${project.primaryLanguage}`,
          `Frameworks detected: ${project.frameworks.join(", ") || "none detected"}`,
          `Files attached: ${request.attachedFiles.length}`,
          `Dependencies: ${Object.keys(project.dependencies).join(", ") || "none detected"}`
        );
      }
    } else if (snapshot.project) {
      projectSummaryLines.push(
        `Primary language: ${snapshot.project.primaryLanguage}`,
        `Frameworks: ${snapshot.project.frameworks.join(", ") || "none detected"}`
      );
    }

    if (BUG_FIX_TASKS.includes(taskType)) {
      const errorAnalysis = await errorAnalyzerTool.run({ rawError: request.userInput });
      if (errorAnalysis.success && errorAnalysis.data?.errorType) {
        projectSummaryLines.push(
          `Detected error type: ${errorAnalysis.data.errorType}`,
          `Error message: ${errorAnalysis.data.message ?? "unknown"}`,
          `Stack frames: ${errorAnalysis.data.frames
            .map((f) => `${f.file}:${f.line}`)
            .join(", ") || "none parsed"}`
        );
      }
    }

    const transcript = await this.memory.getRecentTranscript(request.sessionId, 10);

    const systemPrompt = buildSystemPrompt(taskType, {
      language,
      preferences: snapshot.preferences,
      projectSummary: projectSummaryLines.length > 0 ? projectSummaryLines.join("\n") : undefined,
    });

    return { taskType, language, model, systemPrompt, transcript };
  }

  private buildMessages(transcript: string, userInput: string): LLMMessage[] {
    const messages: LLMMessage[] = [];
    if (transcript) {
      messages.push({
        role: "user",
        content: `Here is the recent conversation for context:\n${transcript}`,
      });
      messages.push({
        role: "assistant",
        content: "Understood, I have the context. What's the next request?",
      });
    }
    messages.push({ role: "user", content: userInput });
    return messages;
  }

  public async handleRequest(request: EngineRequest): Promise<EngineResponse> {
    const { taskType, model, systemPrompt, transcript } = await this.buildContext(request);

    await this.memory.addMessage(request.sessionId, "user", request.userInput, taskType);

    const messages = this.buildMessages(transcript, request.userInput);
    const completion = await this.llm.complete({ model, systemPrompt, messages });

    const { explanation, files } = parseLLMResponse(completion.text);
    const followUpSuggestions = extractFollowUpSuggestions(explanation);

    const assistantMessage = await this.memory.addMessage(
      request.sessionId,
      "assistant",
      explanation,
      taskType
    );

    if (files.length > 0) {
      await this.memory.recordGeneratedFiles(request.sessionId, assistantMessage.id, files);
    }

    return {
      sessionId: request.sessionId,
      taskType,
      explanation,
      files,
      followUpSuggestions,
      modelUsed: model,
      tokensUsed: { input: completion.inputTokens, output: completion.outputTokens },
    };
  }

  /**
   * Streaming variant. Emits StreamChunk events via `onChunk` as they
   * arrive, then resolves with the final EngineResponse once complete.
   * File boundaries are only known once streaming completes (since the
   * FILE:/code-block markers can't be reliably parsed mid-stream), so
   * "explanation" deltas are streamed live, while files are emitted in
   * full once parsing completes.
   */
  public async handleRequestStreaming(
    request: EngineRequest,
    onChunk: (chunk: StreamChunk) => void
  ): Promise<EngineResponse> {
    const { taskType, model, systemPrompt, transcript } = await this.buildContext(request);

    await this.memory.addMessage(request.sessionId, "user", request.userInput, taskType);

    const messages = this.buildMessages(transcript, request.userInput);

    return new Promise<EngineResponse>((resolve, reject) => {
      const handlers: LLMStreamHandlers = {
        onDelta: (delta) => {
          onChunk({ type: "explanation", sessionId: request.sessionId, delta });
        },
        onDone: async (result) => {
          try {
            const { explanation, files } = parseLLMResponse(result.text);
            const followUpSuggestions = extractFollowUpSuggestions(explanation);

            const assistantMessage = await this.memory.addMessage(
              request.sessionId,
              "assistant",
              explanation,
              taskType
            );

            if (files.length > 0) {
              await this.memory.recordGeneratedFiles(request.sessionId, assistantMessage.id, files);
              for (const file of files) {
                onChunk({
                  type: "file_start",
                  sessionId: request.sessionId,
                  filePath: file.path,
                  language: file.language,
                });
                onChunk({
                  type: "file_chunk",
                  sessionId: request.sessionId,
                  filePath: file.path,
                  delta: file.content,
                });
                onChunk({ type: "file_end", sessionId: request.sessionId, filePath: file.path });
              }
            }

            onChunk({ type: "done", sessionId: request.sessionId });

            resolve({
              sessionId: request.sessionId,
              taskType,
              explanation,
              files,
              followUpSuggestions,
              modelUsed: model,
              tokensUsed: { input: result.inputTokens, output: result.outputTokens },
            });
          } catch (err) {
            reject(err);
          }
        },
        onError: (error) => {
          onChunk({ type: "error", sessionId: request.sessionId, error: error.message });
          reject(error);
        },
      };

      this.llm.stream({ model, systemPrompt, messages }, handlers).catch(reject);
    });
  }
}
