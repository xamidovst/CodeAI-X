/**
 * CodeAI-X AI Engine - LLM Client
 * Path: ai-engine/src/core/llmClient.ts
 *
 * Thin, provider-agnostic wrapper around the Anthropic and OpenAI SDKs.
 * The rest of the engine (Orchestrator, Generators) only ever talks to
 * `LLMClient`, never to a provider SDK directly - this keeps model
 * routing/provider swaps isolated to a single file.
 *
 * API keys are read exclusively from environment variables. They must
 * never be hardcoded or logged.
 */

import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";
import { ModelDefinition } from "../types";

export interface LLMMessage {
  role: "user" | "assistant";
  content: string;
}

export interface LLMCompletionRequest {
  model: ModelDefinition;
  systemPrompt: string;
  messages: LLMMessage[];
  maxTokens?: number;
  temperature?: number;
}

export interface LLMCompletionResult {
  text: string;
  inputTokens: number;
  outputTokens: number;
}

export interface LLMStreamHandlers {
  onDelta: (text: string) => void;
  onDone: (result: LLMCompletionResult) => void;
  onError: (error: Error) => void;
}

export class LLMClient {
  private anthropic: Anthropic | null = null;
  private openai: OpenAI | null = null;

  private getAnthropic(): Anthropic {
    if (!this.anthropic) {
      const apiKey = process.env.ANTHROPIC_API_KEY;
      if (!apiKey) {
        throw new Error("ANTHROPIC_API_KEY environment variable is not set.");
      }
      this.anthropic = new Anthropic({ apiKey });
    }
    return this.anthropic;
  }

  private getOpenAI(): OpenAI {
    if (!this.openai) {
      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) {
        throw new Error("OPENAI_API_KEY environment variable is not set.");
      }
      this.openai = new OpenAI({ apiKey });
    }
    return this.openai;
  }

  public async complete(request: LLMCompletionRequest): Promise<LLMCompletionResult> {
    if (request.model.provider === "anthropic") {
      return this.completeAnthropic(request);
    }
    return this.completeOpenAI(request);
  }

  public async stream(
    request: LLMCompletionRequest,
    handlers: LLMStreamHandlers
  ): Promise<void> {
    try {
      if (request.model.provider === "anthropic") {
        await this.streamAnthropic(request, handlers);
      } else {
        await this.streamOpenAI(request, handlers);
      }
    } catch (err) {
      handlers.onError(err instanceof Error ? err : new Error("Unknown streaming error."));
    }
  }

  private async completeAnthropic(request: LLMCompletionRequest): Promise<LLMCompletionResult> {
    const client = this.getAnthropic();
    const response = await client.messages.create({
      model: request.model.model,
      max_tokens: request.maxTokens ?? request.model.maxOutputTokens,
      temperature: request.temperature ?? 0.2,
      system: request.systemPrompt,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
    });

    const text = response.content
      .filter((block): block is Anthropic.TextBlock => block.type === "text")
      .map((block) => block.text)
      .join("\n");

    return {
      text,
      inputTokens: response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
    };
  }

  private async streamAnthropic(
    request: LLMCompletionRequest,
    handlers: LLMStreamHandlers
  ): Promise<void> {
    const client = this.getAnthropic();
    const stream = client.messages.stream({
      model: request.model.model,
      max_tokens: request.maxTokens ?? request.model.maxOutputTokens,
      temperature: request.temperature ?? 0.2,
      system: request.systemPrompt,
      messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
    });

    stream.on("text", (delta) => handlers.onDelta(delta));

    const finalMessage = await stream.finalMessage();
    const text = finalMessage.content
      .filter((block): block is Anthropic.TextBlock => block.type === "text")
      .map((block) => block.text)
      .join("\n");

    handlers.onDone({
      text,
      inputTokens: finalMessage.usage.input_tokens,
      outputTokens: finalMessage.usage.output_tokens,
    });
  }

  private async completeOpenAI(request: LLMCompletionRequest): Promise<LLMCompletionResult> {
    const client = this.getOpenAI();
    const response = await client.chat.completions.create({
      model: request.model.model,
      max_tokens: request.maxTokens ?? request.model.maxOutputTokens,
      temperature: request.temperature ?? 0.2,
      messages: [
        { role: "system", content: request.systemPrompt },
        ...request.messages.map((m) => ({ role: m.role, content: m.content })),
      ],
    });

    return {
      text: response.choices[0]?.message?.content ?? "",
      inputTokens: response.usage?.prompt_tokens ?? 0,
      outputTokens: response.usage?.completion_tokens ?? 0,
    };
  }

  private async streamOpenAI(
    request: LLMCompletionRequest,
    handlers: LLMStreamHandlers
  ): Promise<void> {
    const client = this.getOpenAI();
    const stream = await client.chat.completions.create({
      model: request.model.model,
      max_tokens: request.maxTokens ?? request.model.maxOutputTokens,
      temperature: request.temperature ?? 0.2,
      stream: true,
      messages: [
        { role: "system", content: request.systemPrompt },
        ...request.messages.map((m) => ({ role: m.role, content: m.content })),
      ],
    });

    let fullText = "";
    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content ?? "";
      if (delta) {
        fullText += delta;
        handlers.onDelta(delta);
      }
    }

    handlers.onDone({ text: fullText, inputTokens: 0, outputTokens: 0 });
  }
}
