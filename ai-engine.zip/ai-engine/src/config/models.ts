/**
 * CodeAI-X AI Engine - Model Registry
 * Path: ai-engine/src/config/models.ts
 *
 * Central place that declares which underlying LLMs are available to the
 * engine and what each one is best suited for. The Router (see
 * src/core/router.ts) reads this registry to pick a model per request.
 */

import { ModelDefinition, TaskType } from "../types";

const HEAVY_REASONING_TASKS: TaskType[] = [
  "generate_fullstack_project",
  "generate_architecture",
  "fix_bug",
  "refactor",
  "code_review",
  "optimize_code",
];

const FAST_GENERATION_TASKS: TaskType[] = [
  "generate_readme",
  "generate_documentation",
  "generate_dockerfile",
  "generate_github_actions",
  "generate_sql",
  "generate_cv",
  "generate_portfolio",
  "generate_deployment_guide",
  "generate_prompt",
  "explain_code",
  "general_chat",
];

const CODE_GENERATION_TASKS: TaskType[] = [
  "write_code",
  "generate_website",
  "generate_react_app",
  "generate_node_app",
  "generate_python_app",
  "generate_java_app",
  "generate_flutter_app",
  "generate_telegram_bot",
  "generate_discord_bot",
  "generate_rest_api",
  "generate_database",
  "generate_tests",
];

export const MODEL_REGISTRY: ModelDefinition[] = [
  {
    provider: "anthropic",
    model: "claude-opus-4-8",
    contextWindow: 200_000,
    maxOutputTokens: 8_192,
    costTier: "high",
    strengths: HEAVY_REASONING_TASKS,
  },
  {
    provider: "anthropic",
    model: "claude-sonnet-5",
    contextWindow: 200_000,
    maxOutputTokens: 8_192,
    costTier: "medium",
    strengths: CODE_GENERATION_TASKS,
  },
  {
    provider: "anthropic",
    model: "claude-haiku-4-5-20251001",
    contextWindow: 200_000,
    maxOutputTokens: 4_096,
    costTier: "low",
    strengths: FAST_GENERATION_TASKS,
  },
];

export const DEFAULT_MODEL: ModelDefinition = MODEL_REGISTRY[1];

export function getModelsForTask(taskType: TaskType): ModelDefinition[] {
  const matches = MODEL_REGISTRY.filter((m) => m.strengths.includes(taskType));
  return matches.length > 0 ? matches : [DEFAULT_MODEL];
}
