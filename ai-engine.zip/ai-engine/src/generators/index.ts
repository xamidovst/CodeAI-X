/**
 * CodeAI-X AI Engine - Generators
 * Path: ai-engine/src/generators/index.ts
 *
 * Generators are thin, convenience wrappers around the Orchestrator that
 * pin a specific TaskType and shape the user-facing API around a
 * specific use case (e.g. "generate a README from these files") instead
 * of requiring the caller to build a free-form prompt.
 *
 * Every generator ultimately calls `Orchestrator.handleRequest`, so all
 * generated output still goes through the same routing, memory, and
 * response-parsing pipeline as the rest of the engine.
 */

import { Orchestrator } from "../core/orchestrator";
import { EngineResponse, SupportedLanguage, TaskType } from "../types";

export interface GeneratorFileInput {
  path: string;
  content: string;
}

interface RunGeneratorOptions {
  sessionId: string;
  taskType: TaskType;
  instructions: string;
  files?: GeneratorFileInput[];
  languageHint?: SupportedLanguage;
}

async function runGenerator(
  orchestrator: Orchestrator,
  options: RunGeneratorOptions
): Promise<EngineResponse> {
  return orchestrator.handleRequest({
    sessionId: options.sessionId,
    userInput: options.instructions,
    taskTypeHint: options.taskType,
    languageHint: options.languageHint,
    attachedFiles: options.files,
  });
}

// ---------------------------------------------------------------------------
// README Generator
// ---------------------------------------------------------------------------

export interface ReadmeGeneratorInput {
  sessionId: string;
  projectName: string;
  description: string;
  files: GeneratorFileInput[];
  installSteps?: string[];
  usageExample?: string;
}

export async function generateReadme(
  orchestrator: Orchestrator,
  input: ReadmeGeneratorInput
): Promise<EngineResponse> {
  const instructions = `Generate a complete README.md for the project "${input.projectName}".
Description: ${input.description}
${input.installSteps ? `Known install steps: ${input.installSteps.join(" -> ")}` : ""}
${input.usageExample ? `Usage example to include:\n${input.usageExample}` : ""}
Base all claims strictly on the attached project files - do not invent features that aren't present.`;

  return runGenerator(orchestrator, {
    sessionId: input.sessionId,
    taskType: "generate_readme",
    instructions,
    files: input.files,
  });
}

// ---------------------------------------------------------------------------
// Unit Test Generator
// ---------------------------------------------------------------------------

export interface TestGeneratorInput {
  sessionId: string;
  targetFile: GeneratorFileInput;
  testFramework?: string;
  languageHint?: SupportedLanguage;
}

export async function generateTests(
  orchestrator: Orchestrator,
  input: TestGeneratorInput
): Promise<EngineResponse> {
  const instructions = `Write complete unit tests for the following file: ${input.targetFile.path}.
${input.testFramework ? `Use the ${input.testFramework} testing framework.` : "Use the standard testing framework for this language."}
Cover happy paths, edge cases, and error conditions. The file content is attached.`;

  return runGenerator(orchestrator, {
    sessionId: input.sessionId,
    taskType: "generate_tests",
    instructions,
    files: [input.targetFile],
    languageHint: input.languageHint,
  });
}

// ---------------------------------------------------------------------------
// Dockerfile Generator
// ---------------------------------------------------------------------------

export interface DockerfileGeneratorInput {
  sessionId: string;
  languageHint: SupportedLanguage;
  entryPoint: string;
  exposedPort?: number;
  files?: GeneratorFileInput[];
}

export async function generateDockerfile(
  orchestrator: Orchestrator,
  input: DockerfileGeneratorInput
): Promise<EngineResponse> {
  const instructions = `Generate a production-ready multi-stage Dockerfile (and .dockerignore) for this ${input.languageHint} application.
Entry point: ${input.entryPoint}.
${input.exposedPort ? `The app listens on port ${input.exposedPort}.` : ""}
Use a non-root user in the final image and pin base image versions.`;

  return runGenerator(orchestrator, {
    sessionId: input.sessionId,
    taskType: "generate_dockerfile",
    instructions,
    files: input.files,
    languageHint: input.languageHint,
  });
}

// ---------------------------------------------------------------------------
// GitHub Actions Generator
// ---------------------------------------------------------------------------

export interface GithubActionsGeneratorInput {
  sessionId: string;
  languageHint: SupportedLanguage;
  steps: ("lint" | "test" | "build" | "deploy")[];
  deployTarget?: string;
}

export async function generateGithubActions(
  orchestrator: Orchestrator,
  input: GithubActionsGeneratorInput
): Promise<EngineResponse> {
  const instructions = `Generate a GitHub Actions workflow (.github/workflows/ci.yml) for a ${input.languageHint} project.
Required jobs, in order: ${input.steps.join(" -> ")}.
${input.deployTarget ? `Deploy target: ${input.deployTarget}. Use GitHub Secrets for any credentials.` : ""}
Pin all action versions.`;

  return runGenerator(orchestrator, {
    sessionId: input.sessionId,
    taskType: "generate_github_actions",
    instructions,
    languageHint: input.languageHint,
  });
}

// ---------------------------------------------------------------------------
// REST API Generator
// ---------------------------------------------------------------------------

export interface RestApiGeneratorInput {
  sessionId: string;
  languageHint: SupportedLanguage;
  resourceName: string;
  fields: { name: string; type: string }[];
  authRequired: boolean;
}

export async function generateRestApi(
  orchestrator: Orchestrator,
  input: RestApiGeneratorInput
): Promise<EngineResponse> {
  const fieldList = input.fields.map((f) => `${f.name}: ${f.type}`).join(", ");
  const instructions = `Generate a complete REST API for the "${input.resourceName}" resource using ${input.languageHint}.
Fields: ${fieldList}.
Implement full CRUD endpoints (Create, Read, Read-all, Update, Delete).
${input.authRequired ? "Protect all write endpoints with authentication middleware." : "No authentication required for this resource."}
Include request validation and proper HTTP status codes.`;

  return runGenerator(orchestrator, {
    sessionId: input.sessionId,
    taskType: "generate_rest_api",
    instructions,
    languageHint: input.languageHint,
  });
}
