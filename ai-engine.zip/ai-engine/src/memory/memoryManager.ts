/**
 * CodeAI-X AI Engine - Memory Manager
 * Path: ai-engine/src/memory/memoryManager.ts
 *
 * In-process session memory: conversation history, generated files,
 * project context (file tree, language, dependencies) and user
 * preferences. This is intentionally storage-agnostic - the backend team
 * is responsible for persistence; this class only defines the in-memory
 * shape and the operations the AI Engine needs during a session.
 *
 * `MemoryStore` is a pluggable interface so the backend can inject a
 * Redis/Postgres-backed implementation without the AI engine caring.
 */

import { randomUUID } from "crypto";
import {
  ChatMessage,
  GeneratedFile,
  ProjectContext,
  SessionMemorySnapshot,
  UserPreferences,
} from "../types";

const DEFAULT_PREFERENCES: UserPreferences = {
  preferredLanguage: null,
  responseVerbosity: "normal",
  codeStyle: "standard",
  includeComments: true,
  includeTests: false,
};

const MAX_CONVERSATION_MESSAGES = 50;
const MAX_GENERATED_FILES = 100;

export interface MemoryStore {
  get(sessionId: string): Promise<SessionMemorySnapshot | null>;
  set(sessionId: string, snapshot: SessionMemorySnapshot): Promise<void>;
  delete(sessionId: string): Promise<void>;
}

/**
 * Default in-memory store. Suitable for local dev / single-instance
 * deployments. Production deployments should inject a persistent
 * MemoryStore implementation (Redis, Postgres, etc.) from the backend.
 */
export class InMemoryStore implements MemoryStore {
  private sessions = new Map<string, SessionMemorySnapshot>();

  public async get(sessionId: string): Promise<SessionMemorySnapshot | null> {
    return this.sessions.get(sessionId) ?? null;
  }

  public async set(sessionId: string, snapshot: SessionMemorySnapshot): Promise<void> {
    this.sessions.set(sessionId, snapshot);
  }

  public async delete(sessionId: string): Promise<void> {
    this.sessions.delete(sessionId);
  }
}

export class MemoryManager {
  private readonly store: MemoryStore;

  constructor(store?: MemoryStore) {
    this.store = store ?? new InMemoryStore();
  }

  private emptySnapshot(sessionId: string): SessionMemorySnapshot {
    return {
      sessionId,
      conversation: [],
      generatedFiles: [],
      project: null,
      preferences: { ...DEFAULT_PREFERENCES },
    };
  }

  public async getSnapshot(sessionId: string): Promise<SessionMemorySnapshot> {
    const existing = await this.store.get(sessionId);
    return existing ?? this.emptySnapshot(sessionId);
  }

  public async addMessage(
    sessionId: string,
    role: ChatMessage["role"],
    content: string,
    taskType?: ChatMessage["taskType"],
    metadata?: Record<string, unknown>
  ): Promise<ChatMessage> {
    const snapshot = await this.getSnapshot(sessionId);
    const message: ChatMessage = {
      id: randomUUID(),
      role,
      content,
      taskType,
      createdAt: new Date().toISOString(),
      metadata,
    };

    snapshot.conversation.push(message);
    if (snapshot.conversation.length > MAX_CONVERSATION_MESSAGES) {
      snapshot.conversation = snapshot.conversation.slice(-MAX_CONVERSATION_MESSAGES);
    }

    await this.store.set(sessionId, snapshot);
    return message;
  }

  public async recordGeneratedFiles(
    sessionId: string,
    messageId: string,
    files: { path: string; language: GeneratedFile["language"]; content: string }[]
  ): Promise<void> {
    const snapshot = await this.getSnapshot(sessionId);
    const now = new Date().toISOString();

    for (const file of files) {
      snapshot.generatedFiles.push({
        path: file.path,
        language: file.language,
        content: file.content,
        createdAt: now,
        messageId,
      });
    }

    if (snapshot.generatedFiles.length > MAX_GENERATED_FILES) {
      snapshot.generatedFiles = snapshot.generatedFiles.slice(-MAX_GENERATED_FILES);
    }

    await this.store.set(sessionId, snapshot);
  }

  public async updateProjectContext(
    sessionId: string,
    project: ProjectContext
  ): Promise<void> {
    const snapshot = await this.getSnapshot(sessionId);
    snapshot.project = project;
    await this.store.set(sessionId, snapshot);
  }

  public async updatePreferences(
    sessionId: string,
    preferences: Partial<UserPreferences>
  ): Promise<UserPreferences> {
    const snapshot = await this.getSnapshot(sessionId);
    snapshot.preferences = { ...snapshot.preferences, ...preferences };
    await this.store.set(sessionId, snapshot);
    return snapshot.preferences;
  }

  /**
   * Returns the most recent N messages formatted as a compact transcript,
   * used to inject conversational context into prompts without blowing
   * the token budget.
   */
  public async getRecentTranscript(sessionId: string, limit = 10): Promise<string> {
    const snapshot = await this.getSnapshot(sessionId);
    const recent = snapshot.conversation.slice(-limit);
    return recent
      .map((m) => `[${m.role.toUpperCase()}]: ${m.content}`)
      .join("\n");
  }

  public async findLastFileByPath(
    sessionId: string,
    path: string
  ): Promise<GeneratedFile | null> {
    const snapshot = await this.getSnapshot(sessionId);
    const matches = snapshot.generatedFiles.filter((f) => f.path === path);
    return matches.length > 0 ? matches[matches.length - 1] : null;
  }

  public async clearSession(sessionId: string): Promise<void> {
    await this.store.delete(sessionId);
  }
}
