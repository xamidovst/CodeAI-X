# Postgres init scripts

Drop any `.sql` or `.sh` files here and Postgres will run them, in
alphabetical order, the **first time** the `postgres_data` volume is
created (not on every restart).

Suggested naming convention:

- `01_extensions.sql` — e.g. `CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`
- `02_roles.sql` — additional DB roles/grants beyond the default superuser
- `03_seed.sql` — any non-sensitive seed data (never put secrets here)

This directory is intentionally empty of application schema — schema
and migrations are owned by the backend team's migration tool, not DevOps.
